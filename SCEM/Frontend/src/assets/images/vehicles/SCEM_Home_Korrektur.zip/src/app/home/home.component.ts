import { Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import Keycloak from 'keycloak-js';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private readonly keycloak = inject(Keycloak);

  isAuthenticated = false;
  firstName = 'User';

  async ngOnInit(): Promise<void> {
    this.isAuthenticated = Boolean(this.keycloak.authenticated);

    if (!this.isAuthenticated) return;

    const token = this.keycloak.tokenParsed;
    const givenName = token?.['given_name'];
    const fullName = token?.['name'];
    const username = token?.['preferred_username'];

    const initialName = [givenName, fullName, username]
      .find((item): item is string => typeof item === 'string' && item.trim().length > 0);

    if (initialName) this.firstName = this.extractFirstName(initialName);

    try {
      const profile = await this.keycloak.loadUserProfile();
      const profileName = profile.firstName || profile.username;
      if (profileName?.trim()) {
        this.firstName = this.extractFirstName(profileName);
      }
    } catch {
      // Keep the name from the token if the profile endpoint is unavailable.
    }
  }

  private extractFirstName(value: string): string {
    return value.trim().split(/[\s_]+/)[0] || 'User';
  }

  login(): void {
    void this.keycloak.login();
  }

  register(): void {
    void this.keycloak.register();
  }

  logout(): void {
    void this.keycloak.logout();
  }
}
